<?php 

/*
 * Les Variables globales pour configurer le système 
 * Les informations sur votre Auto Ecole 
 */

$config = array(
    'NOM' => 'Gloire Auto Ecole',
    'NUMERO' => '+(226) 25-00-00-92',
    'EMAIL' => 'gloire@yahoo.fr',
    'LOCATION' => 'Ouagadougou BP',
    'ADRESSE' => '',    
);



?>