<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	
	<title>Liste des élèves</title>
   
</head>
<body> 
<?php 

   include_once("../../model/Examen.class.php");
   include_once("../../model/Eleve.class.php"); 
   $examens = Examen::afficherParticipantExamenOne($_GET['id_examen']);

   $infos = Examen::afficherExamenOne($_GET['id_examen']);      


    ob_start();
    require("../vendor/fpdf/fpdf.php");
	
	$pdf = new FPDF('P','mm','A4'); 
    // $pdf = new FPDF('P','mm',array(195,291));
	$pdf->SetAutoPageBreak('On'); 
	$pdf->AddPage();
	// Image de fond d'ecran
	$pdf->Image('head2.png', 0, 0, $pdf->GetPageWidth(), 35);
	$pdf->SetTextColor(23);
	$pdf->SetFont('times','',8);
	// 	$pdf->text(4, 5, utf8_decode("largeur, hauteur"));	 
	//$pdf->text(10, 35 , utf8_decode("MON AUTO ECOLE")); 
	
	
	$pdf->SetFont('times','B',15);
	$pdf->SetY(50); 
	$pdf->SetX(30);
	$pdf->MultiCell($pdf->GetPageWidth()-70,10,utf8_decode(" Examen de  ".$infos[0]->type), 1, 'C', false);
	
	$pdf->SetFont('times','B',10);
	$pdf->text(10, 40 , utf8_decode("Date : ".date('d/m/Y',strtotime($infos[0]->date_examen))));

	$pdf->SetFont('times','B',10);
	$pdf->text(10, 45 , utf8_decode("Examinateur : ".$infos[0]->examinateur));		
		
	$pdf->SetFillColor(224,235,255);
	$pdf->SetFont('times','B',11);
	$w = array(8, 50, 60, 35, 25, 20);
	$pdf->SetY(70); 
	$pdf->SetX(5); 
	$pdf->Cell($w[0],10,utf8_decode("N°"),1,0,'C',true);
	$pdf->Cell($w[1],10,utf8_decode("Nom"),1,0,'C',true);
	$pdf->Cell($w[2],10,utf8_decode("Prenom"),1,0,'C',true);
	$pdf->Cell($w[3],10,utf8_decode("Date de Naissance"),1,0,'C',true);
	$pdf->Cell($w[4],10,utf8_decode("Contact"),1,0,'C',true);
	$pdf->Cell($w[5],10,utf8_decode("Résultat"),1,0,'C',true);	   
    $cp = 1;
    $x = 80;

    foreach ($examens as $examen ) :
    	$pdf->SetFont('times','',13);
		$pdf->SetY($x);
		$pdf->SetX(5);  
		$pdf->Cell($w[0],10,utf8_decode($cp),1,0,'C',false);
		$pdf->Cell($w[1],10,utf8_decode($examen->nom),1,0,'C',false);
		$pdf->Cell($w[2],10,utf8_decode($examen->prenom),1,0,'C',false);
		$pdf->Cell($w[3],10,utf8_decode($examen->dob),1,0,'C',false);
		$pdf->Cell($w[4],10,utf8_decode($examen->contact),1,0,'C',false);
		$pdf->Cell($w[5],10,utf8_decode($examen->resultat),1,0,'C',false);				
		$cp+=1;
		$x+=10;
		if ($x > 270) 
		{
			$pdf->AddPage();
			$x = 10;
		}
       
    endforeach;

	//Corps 
	//$pdf->SetFont('Arial','',11);
	$pdf->SetFont('times','', 11); 
	$pdf->SetTextColor(0);	 

	$pdf->Output();
	// $pdf->Output(F,'../filename2.pdf'); // ça marche aussi
	ob_end_flush(); 
  
?>
 
</body>
</html>
