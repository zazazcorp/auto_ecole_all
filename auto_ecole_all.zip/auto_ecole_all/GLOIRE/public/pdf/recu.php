<!DOCTYPE html>
<html lang="fr">
<meta charset="utf-8">
<!-- <?php // import swal from 'sweetalert'; ?> -->

<head>
  <title> Reçu de  paiement </title>  	 
</head>
<body> 

<?php 
	include_once("../../model/Paiement.class.php");
	include_once("../../model/Eleve.class.php");

	$recu = Paiement::afficherEleve($_GET['id_paiement']); 

    ob_start();
    require("../vendor/fpdf/fpdf.php");
	$pdf = new FPDF('P','mm','A4'); 
    // $pdf = new FPDF('P','mm',array(195,291));
	$pdf->SetAutoPageBreak('On'); 
	$pdf->AddPage();

	// Image de fond d'ecran
    $pdf->Image('head2.png', 0, 0, $pdf->GetPageWidth(), 35);
	$pdf->SetTextColor(23);
	/*$pdf->SetFont('times','',10);*/
	// 	$pdf->text(4, 5, utf8_decode("largeur, hauteur"));
	$pdf->SetFont('times','B',14); 
	$pdf->text(30, 55 , utf8_decode("N° Reçu : ".$recu[0]->numero));
	
	$pdf->SetFont('times','B',15);
	$pdf->SetY(35); 
	$pdf->SetX(50);
	$pdf->MultiCell($pdf->GetPageWidth()-70,10,utf8_decode(" Reçu de Paiement de : ".$recu[0]->type), 1, 'C', false);

    $pdf->SetFont('times','B',11); 
	$pdf->text(30, 60 , utf8_decode("Reçu de :  "));
	$pdf->SetFont('times','B',11);
	$pdf->text(70, 60 , utf8_decode($recu[0]->nom.' '.$recu[0]->prenom));


	$pdf->SetFont('times','B',11); 
	$pdf->text(30, 63 , utf8_decode("Catégorie :  "));
	$pdf->SetFont('times','B',11);
	$pdf->text(70, 63 , utf8_decode($recu[0]->categorie));

	$pdf->SetFont('times','B',11); 
	$pdf->text(30, 67 , utf8_decode("Reliquat :  "));
	$pdf->SetFont('times','B',11);
	$pdf->text(70, 67 , utf8_decode($_GET['r']));


	$pdf->SetFont('times','',10);		
		
	$pdf->SetFillColor(224,235,255);
	$pdf->SetFont('times','B',11);
	$w = array(30, 40, 30, 70);
	$pdf->SetY(70); 
	$pdf->SetX(30); 
	$pdf->Cell($w[0],10,utf8_decode("N° Reçu"),1,0,'C',true);
	$pdf->Cell($w[1],10,utf8_decode("Date de Paiement"),1,0,'C',true);
	$pdf->Cell($w[2],10,utf8_decode("Somme versée"),1,0,'C',true);
	$pdf->Cell($w[3],10,utf8_decode("Désignation"),1,0,'C',true);

	$hists = Paiement::afficher($_GET['id_eleve']);
	$x = 80;

	foreach ($hists as $hist ) :
		$pdf->SetFont('times','',10);
		$pdf->SetY($x);
		$pdf->SetX(30);  
		$pdf->Cell($w[0],10,utf8_decode($hist->numero),1,0,'C',false);
		$pdf->Cell($w[1],10,utf8_decode(date('d/m/Y',strtotime($hist->date_paiement))),1,0,'C',false);
		$pdf->Cell($w[2],10,utf8_decode($hist->somme),1,0,'C',false);
		$pdf->Cell($w[3],10,utf8_decode($hist->type),1,0,'C',false);
		$x+=10;
	endforeach;


	$pdf->SetFont('times','B',12);
	$pdf->text(30, 130 , utf8_decode('Ouagadougou, le '.(date('d/m/Y',strtotime($recu[0]->date_paiement)))) );
	$pdf->SetFont('times','B',11);
	$pdf->text(140, 130 , utf8_decode("Caisse "));
	$pdf->SetFont('times','',10);
	$pdf->text(1, 140 , utf8_decode("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"));
	
		
	
	// $pdf->MultiCell($pdf->GetPageWidth()-4,5,utf8_decode("Cette carte ... test"), 1, 'J');
    
	//Corps 
	//$pdf->SetFont('Arial','',11);
	$pdf->SetFont('times','', 11); 
	$pdf->SetTextColor(0);	 

	$pdf->Output();
	// $pdf->Output(F,'../filename2.pdf'); // ça marche aussi
	ob_end_flush(); 
  
?>
 
</body>
</html>
