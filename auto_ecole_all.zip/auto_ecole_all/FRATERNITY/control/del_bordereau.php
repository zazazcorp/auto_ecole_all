<?php 

include_once '../model/Bordereau.class.php';

if ( isset($_POST['id_bord_csv']) AND isset($_POST['date_depot']) ) 
{
    $id=$_POST['id_bord_csv'];
     Bordereau::supprimerEleveCsv($id);
    header('location:../view/index.php?page=bordereau&date_depot='.$_POST['date_depot']);
}
