<?php 

include_once'../model/Bordereau.class.php';

if(isset($_FILES)){
    $mimes = array('application/vnd.ms-excel','text/plain','text/csv','text/tsv');
    if(in_array($_FILES['file']['type'],$mimes)){

            $path ="../public/fichiers/";
            $file = basename($_FILES['file']['name']);
            move_uploaded_file($_FILES['file']['tmp_name'],$path.$file);

            
            $nom = $_FILES['file']['name'];
            $nom = $path.$nom;

            $response = Bordereau::import($nom, $_POST['date_depot']);

            if($response == 1){
                header('Location:../view/index.php?page=bordereau&date_depot='.$_POST["date_depot"]);
                               
            }
            else
            {
                echo '
                 Erreur echec d\'importation du fichier !!!
                ';
            }
        }
        else
        {
            echo '<h3> Format du fichier incorrect </h3>';
        }    
 }
else
{
    echo '
    Aucun fichier selectionné !
    ';
}




 ?>