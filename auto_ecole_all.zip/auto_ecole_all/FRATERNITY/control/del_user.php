<?php 
   session_start();

	include_once '../model/User.class.php';

	if ( isset($_POST['id_user']) AND $_SESSION['id'] != $_POST['id_user'] ) 
	{
		User::supprimer($_POST['id_user']);
		header('location:../view/index.php?page=utilisateur');
	}
	else
	{
		echo '<h3 style="color:red">
		         Impossible de supprimer l\'utilisateur en cours 
		      </h3>';
	}

 ?>
