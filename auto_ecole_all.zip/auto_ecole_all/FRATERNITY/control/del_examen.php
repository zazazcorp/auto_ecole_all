<?php 

	include_once '../model/Examen.class.php';

	if ( isset($_POST['id_examen'])) 
	{
		Examen::supprimer($_POST['id_examen']);
		header('location:../view/index.php?page=examen');
	}
	else
	{
		echo $_POST['id_examen'];
	}




 ?>