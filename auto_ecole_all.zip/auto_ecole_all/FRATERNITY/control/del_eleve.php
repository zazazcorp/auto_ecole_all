<?php 

	include_once '../model/Eleve.class.php';

	if ( isset($_POST['id_eleve'])) 
	{
		Eleve::supprimer($_POST['id_eleve']);
		header('location:../view/index.php?page=eleve');
	}
	else
	{
		echo $_POST['id_eleve'];
	}




 ?>