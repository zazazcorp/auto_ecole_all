<?php 

include_once "../model/Examen.class.php";

if(isset($_POST['id_examen'])){
    
    $exam =$_POST['id_examen'];

    if(isset( $_POST['eleve']))
    {
        foreach ($_POST['eleve'] as $el) {
            
            $data = array(
                'examen' => $exam,
                'eleve' => $el
            );
            Examen::registerProgram($data);           
        }
    }

    header('location:../view/index.php?page=examen');


    
}




