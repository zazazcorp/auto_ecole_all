<?php 

  include_once '../model/Caisse.class.php';

  if (isset($_POST['type']) AND isset($_POST['somme']) AND isset($_POST['desc']) AND isset($_POST['mode']) AND isset($_POST['date']) ) 
  {
  	$type = strip_tags(htmlspecialchars(trim($_POST['type'])));
	$somme = strip_tags(htmlspecialchars(trim($_POST['somme'])));
	$desc = strip_tags(htmlspecialchars(trim($_POST['desc'])));
	$mode = strip_tags(htmlspecialchars(trim($_POST['mode'])));
	$date = strip_tags(htmlspecialchars(trim($_POST['date'])));
	$compte = strip_tags(htmlspecialchars(trim($_POST['compte'])));
	
	
	$data = array(
		'type' => $type,
		'somme' => $somme,
		'desc' => $desc,
		'compte' => $compte,
		'mode' => $mode,
	    'date' => $date);
	Caisse::register($data);

	header('location:../view/index.php?page=caisse');
  }
  else
  {?>
  	<script type="text/javascript">
  		alert("Impossible champs vides")
  	</script>
  	
  <?php }
 ?>