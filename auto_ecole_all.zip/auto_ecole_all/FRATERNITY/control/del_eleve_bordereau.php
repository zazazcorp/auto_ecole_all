<?php 

include_once '../model/Bordereau.class.php';

if ( isset($_POST['id_bordereau']) AND isset($_POST['date']) ) 
{
    $id=$_POST['id_bordereau'];
     Bordereau::supprimerEleveBordereau($id);
    header('location:../view/index.php?page=bordereau&date_depot='.$_POST['date']);
}
