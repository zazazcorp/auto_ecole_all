<?php 

include_once "../model/Bordereau.class.php";

if(isset( $_POST['date_depot']))
{
    $date =  $_POST['date_depot'];
    foreach ($_POST['eleve'] as $el) {
        $data = array(
            'date_depot' => $date,
            'eleve' => $el
        );
        Bordereau::addBordereau($data);
                  
    }
    header('location:../view/index.php?page=eleve');
}




