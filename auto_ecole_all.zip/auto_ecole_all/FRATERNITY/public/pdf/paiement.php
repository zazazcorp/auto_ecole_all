<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	
	<title>Liste des élèves </title>
   
</head>
<body> 
<?php 

   include_once("../../model/Paiement.class.php");
   include_once("../../model/Eleve.class.php");

   if ($_GET['ind'] == 'impaye') 
   {
   	  $eleves = Eleve::afficherImpaye();
   	  $acc = 'impayés';
   }
   elseif ($_GET['ind'] == 'redevable') 
   {
   	  $eleves = Eleve::afficherPaiement();
   	  $acc = 'redevables';
   }
   else
   {
      $eleves = Eleve::afficherPaiement();
      $acc = 'à jour';
   }
  
    


    ob_start();
    require("../vendor/fpdf/fpdf.php");
	
	$pdf = new FPDF('P','mm','A4'); 
    // $pdf = new FPDF('P','mm',array(195,291));
	$pdf->SetAutoPageBreak('On'); 
	$pdf->AddPage();
	// Image de fond d'ecran
	$pdf->Image('head.png', 0, 0, $pdf->GetPageWidth(), 45);
	$pdf->SetTextColor(23);
	$pdf->SetFont('times','',8);
	// 	$pdf->text(4, 5, utf8_decode("largeur, hauteur"));

	$pdf->text(10, 48 , utf8_decode("Date du jour : ".date('d/m/Y H:i:s',strtotime(date('Y-m-d H:i:s')))));
	
	
	
	$pdf->SetFont('times','B',15);
	$pdf->SetY(50); 
	$pdf->SetX(30);
	$pdf->MultiCell($pdf->GetPageWidth()-70,10,utf8_decode(" Liste des élèves  : ".$acc), 1, 'C', false);
	
	$pdf->SetFont('times','',10);		
		
	$pdf->SetFillColor(224,235,255);
	$pdf->SetFont('times','B',11);
	$w = array(8, 40, 70, 16, 20, 15, 15, 20);
	$pdf->SetY(70); 
	$pdf->SetX(5); 
	$pdf->Cell($w[0],10,utf8_decode("N°"),1,0,'C',true);
	$pdf->Cell($w[1],10,utf8_decode("Nom"),1,0,'C',true);
	$pdf->Cell($w[2],10,utf8_decode("Prenom"),1,0,'C',true);
	$pdf->Cell($w[3],10,utf8_decode("Catégorie"),1,0,'C',true);
	$pdf->Cell($w[4],10,utf8_decode("Forfait"),1,0,'C',true);
	$pdf->Cell($w[5],10,utf8_decode("Solde"),1,0,'C',true);
	$pdf->Cell($w[6],10,utf8_decode("Payé"),1,0,'C',true); 
	$pdf->Cell($w[7],10,utf8_decode("Reliquat"),1,0,'C',true);    
    $cp = 1;
    $x = 80;

    $cu_some =0;
    $cu_solde = 0;    


    if ($_GET['ind'] == 'redevable') 
    {
    	foreach ($eleves as $eleve ) :
    		if ($eleve->solde > $eleve->some) 
    		{
    			$pdf->SetFont('times','',13);
				$pdf->SetY($x);
				$pdf->SetX(5);  
				$pdf->Cell($w[0],10,utf8_decode($cp),1,0,'C',false);
				$pdf->Cell($w[1],10,utf8_decode($eleve->nom),1,0,'C',false);
				$pdf->Cell($w[2],10,utf8_decode($eleve->prenom),1,0,'C',false);
				$pdf->Cell($w[3],10,utf8_decode($eleve->categorie),1,0,'C',false);
				$pdf->Cell($w[4],10,utf8_decode($eleve->forfait),1,0,'C',false);
				$pdf->Cell($w[5],10,utf8_decode($eleve->solde),1,0,'C',false);
				$pdf->Cell($w[6],10,utf8_decode($eleve->some),1,0,'C',false); 
				$pdf->Cell($w[7],10,utf8_decode($eleve->solde - $eleve->some),1,0,'C',false);
				$cp+=1;
				$x+=10;

				$cu_solde += $eleve->solde;
				$cu_some += $eleve->some;
				


				if ($x > 270) 
				{
					$pdf->AddPage();
					$x = 10;
				}
    		}
    	endforeach;	
    }
    elseif ($_GET['ind'] == 'solde') 
    {
    	foreach ($eleves as $eleve ) :
    		if ($eleve->solde == $eleve->some) 
    		{
    			$pdf->SetFont('times','',13);
				$pdf->SetY($x);
				$pdf->SetX(5);  
				$pdf->Cell($w[0],10,utf8_decode($cp),1,0,'C',false);
				$pdf->Cell($w[1],10,utf8_decode($eleve->nom),1,0,'C',false);
				$pdf->Cell($w[2],10,utf8_decode($eleve->prenom),1,0,'C',false);
				$pdf->Cell($w[3],10,utf8_decode($eleve->categorie),1,0,'C',false);
				$pdf->Cell($w[4],10,utf8_decode($eleve->forfait),1,0,'C',false);
				$pdf->Cell($w[5],10,utf8_decode($eleve->solde),1,0,'C',false);
				$pdf->Cell($w[6],10,utf8_decode($eleve->some),1,0,'C',false); 
				$pdf->Cell($w[7],10,utf8_decode($eleve->solde - $eleve->some),1,0,'C',false);
				$cp+=1;
				$x+=10;

				$cu_solde += $eleve->solde;
				$cu_some += $eleve->some;
				


				if ($x > 270) 
				{
					$pdf->AddPage();
					$x = 10;
				}
    		}
    	endforeach;
    }
    else
    {
    	foreach ($eleves as $eleve ) :
    		
    			$pdf->SetFont('times','',13);
				$pdf->SetY($x);
				$pdf->SetX(5);  
				$pdf->Cell($w[0],10,utf8_decode($cp),1,0,'C',false);
				$pdf->Cell($w[1],10,utf8_decode($eleve->nom),1,0,'C',false);
				$pdf->Cell($w[2],10,utf8_decode($eleve->prenom),1,0,'C',false);
				$pdf->Cell($w[3],10,utf8_decode($eleve->categorie),1,0,'C',false);
				$pdf->Cell($w[4],10,utf8_decode($eleve->forfait),1,0,'C',false);
				$pdf->Cell($w[5],10,utf8_decode($eleve->solde),1,0,'C',false);
				$pdf->Cell($w[6],10,utf8_decode(0),1,0,'C',false); 
				$pdf->Cell($w[7],10,utf8_decode($eleve->solde - 0),1,0,'C',false);
				$cp+=1;
				$x+=10;

				$cu_solde += $eleve->solde;
				$cu_some += 0;
				


				if ($x > 270) 
				{
					$pdf->AddPage();
					$x = 10;
				}
    		
    	endforeach;
    }

        $pdf->SetFont('times','B',13);
		$pdf->SetY($x);
		$pdf->SetX(5);  
		$pdf->Cell($w[0],10,utf8_decode("T"),1,0,'C',true);
		$pdf->Cell($w[1],10,utf8_decode("TOTAUX"),1,0,'C',true);
		$pdf->Cell($w[2],10,utf8_decode(""),1,0,'C',true);
		$pdf->Cell($w[3],10,utf8_decode(""),1,0,'C',true);
		$pdf->Cell($w[4],10,utf8_decode(""),1,0,'C',true);
		$pdf->Cell($w[5],10,utf8_decode($cu_solde),1,0,'C',true);
		$pdf->Cell($w[6],10,utf8_decode($cu_some),1,0,'C',true); 
		$pdf->Cell($w[7],10,utf8_decode($cu_solde - $cu_some ),1,0,'C',true);



	


	
	// $pdf->MultiCell($pdf->GetPageWidth()-4,5,utf8_decode("Cette carte ... test"), 1, 'J');
    
	//Corps 
	//$pdf->SetFont('Arial','',11);
	$pdf->SetFont('times','', 11); 
	$pdf->SetTextColor(0);	 

	$pdf->Output();
	// $pdf->Output(F,'../filename2.pdf'); // ça marche aussi
	ob_end_flush(); 
  
?>
 
</body>
</html>
