<!DOCTYPE html>
<html lang="fr">
<head> <!-- c0rei20# -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	
	<title>Liste des élèves</title>
   
</head>
<body> 
<?php 

   include_once("../../model/Bordereau.class.php");
   include_once("../../model/Eleve.class.php"); 
   
   $Examens = Bordereau::afficherBoredereauParticipant($_GET['date_depot']);
   $Programs = Bordereau::afficherParticipantCsv($_GET['date_depot']);

//    $infos = Examen::afficherExamenOne($_GET['id_examen']);


    ob_start();
    require("../vendor/fpdf/fpdf.php");
	
	$pdf = new FPDF('P','mm','A4'); 
    // $pdf = new FPDF('P','mm',array(195,291));
	$pdf->SetAutoPageBreak('On'); 
	$pdf->AddPage();
	// Image de fond d'ecran
	$pdf->Image('head.png', 0, 0, $pdf->GetPageWidth(), 35);
	$pdf->SetTextColor(23);
	$pdf->SetFont('times','',8);
	// 	$pdf->text(4, 5, utf8_decode("largeur, hauteur"));	 
	//$pdf->text(10, 35 , utf8_decode("MON AUTO ECOLE")); 
	
	
	$pdf->SetFont('times','B',15);
	$pdf->SetY(55); 
	$pdf->SetX(30);
	$pdf->MultiCell($pdf->GetPageWidth()-70,10,utf8_decode(" Bordereau de  dépôt"), 1, 'C', false);
	
	$pdf->SetFont('times','B',13);
	$pdf->text(10, 40 , utf8_decode("Date de dépot : ".date('d/m/Y',strtotime($_GET['date_depot'])) ));

			
		
	$pdf->SetFillColor(224,235,255);
	$pdf->SetFont('times','B',11);
	$w = array(8, 95, 35, 63);
	$pdf->SetY(70); 
	$pdf->SetX(5); 
	$pdf->Cell($w[0],10,utf8_decode("N°"),1,0,'C',true);
	$pdf->Cell($w[1],10,utf8_decode("Nom & Prénoms "),1,0,'C',true);
	$pdf->Cell($w[2],10,utf8_decode("Date de Naissance"),1,0,'C',true);
	$pdf->Cell($w[3],10,utf8_decode("Lieu de Naissance"),1,0,'C',true);			   
    $cp = 1;
	$x = 80;

	$fusion = array_merge($Examens,$Programs);	
	$to_short = [];	
	for ($n=0; $n < count($fusion); $n++) { 
		$to_short += [ $fusion[$n]->nom.'*'.$fusion[$n]->prenom.'*'.$fusion[$n]->dob => $fusion[$n]->pob];
	}
	
	ksort($to_short);

	function rd($d)
	{		

		$d1 = strpos($d, '/') ? $d : date('d/m/Y',strtotime($d));
        return $d1;
	}

	foreach ($to_short as $key => $value) 
	{
        
		$pdf->SetFont('times','',13);
		$pdf->SetY($x);
		$pdf->SetX(5);  
		$pdf->Cell($w[0],10,utf8_decode($cp),1,0,'C',false);
		$pdf->Cell($w[1],10,utf8_decode( 
			       explode('*', $key)[0].' '.explode('*', $key)[1]
			        ),1,0,'C',false);
		$pdf->Cell($w[2],10,utf8_decode(rd(explode('*', $key)[2])),1,0,'C',false);
		$pdf->Cell($w[3],10,utf8_decode(explode('*', $value)[0]),1,0,'C',false);				
		$cp+=1;
		$x+=10;
		if ($x > 270) 
		{
			$pdf->AddPage();
			$x = 10;
		}
	}

	$pdf->SetFont('times','B',13);
	$pdf->text(10, 272 , utf8_decode("Date de dépôt "));

	$pdf->SetFont('times','B',13);
	$pdf->text(170, 272 , utf8_decode("Directeur "));
	//Corps 
	//$pdf->SetFont('Arial','',11);
	$pdf->SetFont('times','', 11); 
	$pdf->SetTextColor(0);	 

	$pdf->Output();
	// $pdf->Output(F,'../filename2.pdf'); // ça marche aussi
	ob_end_flush(); 
  
?>
 
</body>
</html>
