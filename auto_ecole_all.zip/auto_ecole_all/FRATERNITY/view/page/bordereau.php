<?php 
include_once "../model/Bordereau.class.php";
  
 ?>
<div class="col col-lg-12">
	<div class="panel-body" style="overflow: scroll;height: 700px;"> 
		<table width="100%" class="table table-striped table-bordered table-hover" id="table_id">
			<div class="panel-header">
				<h4>Liste des dossiers des élèves pour ce dépôt</h4>
          <div class="row">
          <div class="col-lg-3">
              <form method="post" action="../control/upload_csv_bordereau.php" enctype="multipart/form-data">          
                    <input type="file" name="file" required="" >
                    <input type="hidden" name="date_depot" value="<?=$_GET['date_depot']?>">
                    <input type="submit" name="submit" class="btn btn-primary" value="Charger">         
              </form>    
              
            </div>
            <div class="col-lg-2"></div>
            <div class="col-lg-2">
            </div>
            <div class="col-lg-2"></div>
            <div class="col-lg-3">
              <a href="../public/pdf/bordereau.php?date_depot=<?=$_GET['date_depot']?>" target="_blank" class="btn btn-warning"><span class="fa fa-print"></span>
                Imprimer
              </a>              
            </div>
            
          </div>
        
			</div>
		    <thead>
		        <tr>
		            <th>N°</th>
		            <th>Nom</th>
		            <th>Prénom</th>
		            <th>Date de dépôt</th>
                    <th>Agence</th>
		            <th>Action</th>
		        </tr>
		    </thead>
		    <tbody>
                <?php
                    $depot = Bordereau::afficherBoredereauParticipant($_GET['date_depot']); $i=1;
                    foreach($depot as $dt){
                        ?>
                        <tr>
                        <td align="center" ><?= $i ?></td>
                        <td align="center" ><?= $dt->nom ?></td>
                        <td align="center" ><?= $dt->prenom ?></td>
                        <td align="center" ><?= $dt->date_depot ?></td>
                        <td align="center" >Siège</td>
                        <td>

                        <?php if ($_SESSION['fonction'] == 'administrateur') {  ?>
                    <button title="Supprimer" type="button" class="btn btn-danger" data-toggle="modal" data-target="<?='#mod'.$dt->id_eleve;?>">
                      <span class="fa fa-trash"></span>
                    </button>
                    <?php } ?>

                    <!-- Modal -->
                    <div class="modal fade" id="<?='mod'.$dt->id_eleve;?>" tabindex="-1" role="dialog"  aria-hidden="true">
                      <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" >
                              Supprimer <b><?=$dt->nom.' '.$dt->prenom; ?></b>
                            </h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <form method="post" action="../control/del_eleve_bordereau.php">
                              <div class="modal-body">                           
                                <input type="hidden" name="id_bordereau" value="<?=$dt->id_bordereau;?>">
                                <input type="hidden" name="date" value="<?=$dt->date_depot;?>">

                                <button class="btn btn-danger">
                                <h3>
                                    Voulez vous vraiment supprimer cet élève ?                                                 
                                </h3>
                                </button>                                      
                              </div>
                              <div class="modal-footer">                           
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">NON</button>
                                <button type="submit" name="submit" class="btn btn-primary">OUI</button>
                              </div>                                                      
                          </form>
                        </div>
                      </div>
                    </div>  	
		        </td>		        		        
		      </tr>
              <?php $i++; } ?>
                <!-- Programation -->
                <?php $programs = Bordereau::afficherParticipantCsv($_GET['date_depot']); ?>
                <?php foreach ($programs as $program) { ?>

                    <tr>
                      <td align="center"><b><?=$i?></b></td>
                      <td align="center"><b><?=$program->nom ; ?></b></td>
                      <td align="center"><b><?=$program->prenom ; ?></b></td>
                      <td align="center"><?=$_GET['date_depot'] ; ?></td>
                      <td align="center"><?=$program->agence ; ?></td>                      
                      <td>              
                           <!-- Modal must dynam and script -->
                              <?php if ($_SESSION['fonction'] == 'administrateur') {  ?>
                              <button title="Supprimer" type="button" class="btn btn-danger" data-toggle="modal" data-target="<?='#mod'.$program->id_bord_csv;?>">
                                <span class="fa fa-trash"></span>
                              </button>
                              <?php } ?>

                              <!-- Modal -->
                              <div class="modal fade" id="<?='mod'.$program->id_bord_csv;?>" tabindex="-1" role="dialog"  aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title" >
                                        Supprimer <b><?=$program->nom.' '.$program->prenom; ?></b>
                                      </h5>
                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                      </button>
                                    </div>
                                    <form method="post" action="../control/del_bordereau.php">
                                        <div class="modal-body">                           
                                          <input type="hidden" name="id_bord_csv" value="<?=$program->id_bord_csv;?>">
                                          <input type="hidden" name="date_depot" value="<?=$_GET['date_depot'];?>">
                                          <button class="btn btn-danger">
                                          <h3>
                                              Voulez vous vraiment supprimer cet élève ?                                                 
                                          </h3>
                                          </button>                                      
                                        </div>
                                        <div class="modal-footer">                           
                                          <button type="button" class="btn btn-secondary" data-dismiss="modal">NON</button>
                                          <button type="submit" name="submit" class="btn btn-primary">OUI</button>
                                        </div>                                                      
                                    </form>
                                  </div>
                                </div>
                              </div>    
                      </td>                       
                    </tr>
                <?php $i++;}  ?>
		    </tbody>
		</table>
	</div>
</div>

