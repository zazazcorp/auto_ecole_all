<?php include_once '../model/Examen.class.php' ; ?>
<?php include_once '../model/Eleve.class.php' ; ?>

<div class="row">
    <div class="panel panel-default">
        <div class="panel-body">
            <ul class="nav nav-tabs">                
                <li><a href="#ajouter" data-toggle="tab"><h4>Ajouter</h4></a>
                </li>
                <li class="active"><a href="#liste_examen" data-toggle="tab"><h4>Examens</h4></a>
                </li>
                <li><a href="#liste_attente" data-toggle="tab"><h4>En Attente</h4></a>
                </li>
                <li><a href="#liste_program" data-toggle="tab"><h4>Examen programmer</h4></a>
                </li>   
                <li><a href="#liste_terminer" data-toggle="tab"><h4>Terminés</h4></a>
                </li>                                                                
            </ul>
            <div class="tab-content">
            	<!-- Tab Liste Users -->
                <div class="tab-pane fade " id="ajouter">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Ajouter un Examen                            
                        </div>
                        <div class="panel-body">
                            <form role="form" id="formulaire_examen">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>Date Examen</label>
                                        <input id="date" type="date" class="form-control" required>
                                        
                                    </div>
                                    <div class="form-group">
                                        <label>Examinateur</label>
                                        <input id="examinateur" type="text" class="form-control" placeholder="Nom et Prénom examinateur">
                                    </div>                                                                  
                                </div>
                                <div class="col-lg-6">                                    
                                    <div class="form-group">
                                        <label>Type Examen</label>
                                        <select id="type_examen" class="form-control" required>
                                           <option  value="code">Code de Route</option>
                                           <option  value="crenau">Crénau</option>
                                           <option  value="conduite">Conduite</option>                   
                                        </select>
                                    </div>                                                             
                                    <div class="form-group">
                                        <button type="submit" class="btn-lg btn-primary">Ajouter</button>        
                                    </div>                         
                              </div>                                           
                            </form>                            
                        </div>
                    </div>                    
                </div> 

                <!-- Tab Liste Users -->
                <div class="tab-pane fade in active" id="liste_examen">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Listes tous les Examens                            
                        </div>
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example1">
                                <thead>
                                    <tr>
                                        <th>N°</th>
                                        <th>Type Examen</th>
                                        <th>Date Examen</th>
                                        <th>Examinateur</th>
                                        <th>Nombre de Participants</th>                                        
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $exams = Examen::afficher(); $j=1; ?>
                                    <?php foreach ($exams as $exam) : ?>
                                    <tr class="odd gradeX">
                                        <td><?=$j; ?></td>
                                        <td><?=$exam->type; ?></td>
                                        <td><?=$exam->date_examen; ?></td>
                                        <td><?=$exam->examinateur; ?></td>
                                        <td>
                                            <?php 
                                              $part = Examen::afficherParticipant($exam->id_examen);
                                              echo $part[0]->participant;
                                             ?>
                                        </td>                               
                                        <td class="center">                                    
                                            <a title="Détail" class="btn btn-primary" href="index.php?page=de_examen&id_examen=<?=$exam->id_examen;?>">
                                              <span class="fa fa-table"></span>
                                            </a>

                                            <!-- MOD -->
                                            <button title="Modifier" type="button" class="btn btn-success" data-toggle="modal" data-target="<?='#mod'.$j;?>">
                                              <span class="fa fa-pencil"></span>
                                            </button>
                                            <!-- Modal -->
                                            <div class="modal fade" id="<?='mod'.$j;?>" tabindex="-1" role="dialog" aria-labelledby="<?='#mod'.$j;?>" aria-hidden="true">
                                              <div class="modal-dialog modal-dialog-centered" role="document">
                                                <div class="modal-content">
                                                  <div class="modal-header">
                                                    <h5 class="modal-title" id="<?='#mod'.$j;?>">Modifications                                                      
                                                    </h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                      <span aria-hidden="true">&times;</span>
                                                    </button>
                                                  </div>
                                                  <form method="post" action="../control/up_examen.php">
                                                      <div class="modal-body">                           
                                                        <input re type="hidden" name="id_examen" value="<?=$exam->id_examen;?>">
                                                        <label>Date examen</label>
                                                        <input class="form-control" type="date" name="date" value="<?=$exam->date_examen;?>" required><br>
                                                        <label>Examinateur </label>
                                                        <input class="form-control" required type="text" name="examinateur" value="<?=$exam->examinateur;?>"><br>
                                                        <label>Type </label>
                                                        <select class="form-control" required name="type">
                                                            <option selected value="<?=$exam->type;?>"><?=$exam->type;?></option>
                                                            <option value="code">Code de route</option>
                                                            <option value="creanu">Crenau</option>
                                                            <option value="conduite">Conduite</option>
                                                        </select>                                                                                        
                                                      </div>
                                                      <div class="modal-footer">                           
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                        <button type="submit" name="submit" class="btn btn-primary">Modifier</button>
                                                      </div>                                                      
                                                  </form>
                                                </div>
                                              </div>
                                            </div>




                                             <!-- SUPP -->
                                            <button title="Supprimer" type="button" class="btn btn-danger" data-toggle="modal" data-target="<?='#sup'.$j;?>">
                                              <span class="fa fa-trash"></span>
                                            </button>
                                            
                                            <!-- Modal -->
                                            <div class="modal fade" id="<?='sup'.$j;?>" tabindex="-1" role="dialog" aria-labelledby="<?='#sup'.$j;?>" aria-hidden="true">
                                              <div class="modal-dialog modal-dialog-centered" role="document">
                                                <div class="modal-content">
                                                  <div class="modal-header">
                                                    <h5 class="modal-title" id="<?='#sup'.$j;?>">Suppression                                                      
                                                    </h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                      <span aria-hidden="true">&times;</span>
                                                    </button>
                                                  </div>
                                                  <form method="post" action="../control/del_examen.php">
                                                      <div class="modal-body">                           
                                                        <input type="hidden" name="id_examen" value="<?=$exam->id_examen;?>">
                                                        <button class="btn btn-danger">
                                                        <h3>
                                                            Voulez vous vraiment supprimer cet examen ?                                                 
                                                        </h3>
                                                        </button>                                      
                                                      </div>
                                                      <div class="modal-footer">                           
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">NON</button>
                                                        <button type="submit" name="submit" class="btn btn-primary">OUI</button>
                                                      </div>                                                      
                                                  </form>
                                                </div>
                                              </div>
                                            </div>
                                        </td>                                        
                                    </tr>
                                    <?php $j++; ?> 
                                    <?php endforeach; ?>                                      
                                </tbody>
                            </table>                            
                        </div>
                    </div>                    
                </div>

                <!-- Tab Liste Users -->
                <div class="tab-pane fade" id="liste_attente">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Elève en attente pour examen                            
                        </div>
                        <div class="panel-body">
                    <form action="../control/program_exam.php" method="POST">
                        <div style="text-align:center;"> 
                            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#test">examen</button>
                        </div>
                        

                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>N°</th>
                                        <th>Nom</th>
                                        <th>Prénoms</th>
                                        <th>Contact</th>                                       
                                        <th>Catégorie</th> 
                                        <th></th>                                       
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $reds = Eleve::afficherCours(); $j=1; ?>
                                    <?php foreach ($reds as $red) : ?>
                                    <tr class="odd gradeX">
                                        <td><?=$j; ?></td>
                                        <td><?=$red->nom; ?></td>
                                        <td><?=$red->prenom; ?></td>
                                        <td><?=$red->contact; ?></td>                                        
                                        <td><?=$red->categorie; ?></td>
                                        <td>
                                            <input type="checkbox" class="form-group" 
                                                   name="eleve[]" value="<?=$red->id_eleve; ?>">
                                        </td>                                
                                        <td class="center">                                    
                                            <a title="Détail" class="btn btn-primary" href="index.php?page=eleve_examen&id_eleve=<?=$red->id_eleve ; ?>">
                                              <span class="fa fa-pencil"></span>
                                            </a>
                                        </td>                                        
                                    </tr>

                               
                                    <?php $j++; ?> 
                                    <?php endforeach; ?>                                      
                                </tbody>
                            </table>   
                                 <!-- Modal -->
                                 <div class="modal fade" id="test" tabindex="-1" role="dialog" aria-hidden="true">
                                              <div class="modal-dialog modal-dialog-centered" role="document">
                                                <div class="modal-content">
                                                  <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                      <span aria-hidden="true">&times;</span>
                                                    </button>
                                                     </div>
                                                      <div class="modal-body">   
                                                        <div class="form-group">
                                                            <label>Examen à Choisir</label>
                                                            <select id="examen" class="form-control" name="id_examen" required>                       
                                                            <?php 
                                                                    $exams = Examen::afficherExamen();
                                                                ?>
                                                                <?php foreach ($exams as $exam) : ?>
                                                                    <option></option>
                                                                    <option  value="<?=$exam->id_examen?>">
                                                                        <?=$exam->type.' <=> '.$exam->date_examen.' <=> '.$exam->examinateur?>
                                                                    </option>
                                                                <?php endforeach; ?>	

                                                            </select>
                                                        </div>                        
                                                                                             
                                                      </div>
                                                      <div class="modal-footer">                           
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                        <button type="submit" name="submit" class="btn btn-primary">Programmer</button>
                                                      </div>                                                      
                                                  </form>
                                                </div>
                                              </div>
                                            </div>                         
                                        </div>
                                    </div>                    
                                </div>

            	<!--Tab Liste Examen Programmer -->
                <div class="tab-pane fade" id="liste_program">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Programme des examens à faire                            
                        </div>
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example2">
                                <thead>
                                    <tr>
                                        <th>N°</th>
                                        <th>Type Examen</th>
                                        <th>Date Examen</th>
                                        <th>Examinateur</th>                                        
                                        <th>Nombre de participant</th>   
                                        <th>Action</th>                                     
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $exams = Examen::afficher(); $j=1; ?>
                                    <?php foreach ($exams as $exam) : ?>
                                    <tr class="odd gradeX">
                                        <td><?=$j; ?></td>
                                        <td><?=$exam->type; ?></td>
                                        <td><?=$exam->date_examen; ?></td>
                                        <td><?=$exam->examinateur; ?></td>
                                        <td>
                                            <?php 
                                              $part = Examen::afficherProgram($exam->id_examen);
                                              echo $part[0]->nombre;
                                             ?>
                                        </td>                               
                                        <td class="center">                                    
                                            <a title="Détail" class="btn btn-primary" href="index.php?page=program&id_examen=<?=$exam->id_examen;?>">
                                              <span class="fa fa-pencil"></span>
                                            </a>
                                        </td>                                        
                                    </tr>
                                    <?php $j++; ?> 
                                    <?php endforeach; ?>                                      
                                </tbody>
                            </table>                            
                        </div>
                    </div>                    
                </div> 




                <!-- Tab Liste Users -->
                <div class="tab-pane fade" id="liste_terminer">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Tous les Elève qui ont terminé leur examen                            
                        </div>
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example2">
                                <thead>
                                    <tr>
                                        <th>N°</th>
                                        <th>Nom</th>
                                        <th>Prénoms</th>
                                        <th>Contact</th>                                        
                                        <th>Catégorie</th>                                        
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $els = Eleve::afficherStatut(); $k=1; ?>
                                    <?php foreach ($els as $el) : ?>
                                    <tr class="odd gradeX">
                                        <td><?=$k; ?></td>
                                        <td><?=$el->nom; ?></td>
                                        <td><?=$el->prenom; ?></td>
                                        <td><?=$el->contact; ?></td>                                        
                                        <td><?=$el->categorie; ?></td>                                       
                                        <td class="center">                                    
                                            <a title="Détail" class="btn btn-primary" href="index.php?page=eleve_examen&id_eleve=<?=$el->id_eleve ; ?>">
                                              <span class="fa fa-pencil"></span>
                                            </a>
                                        </td>                                        
                                    </tr>
                                    <?php $k++; ?> 
                                    <?php endforeach; ?>                                      
                                </tbody>
                            </table>                            
                        </div>
                    </div>                    
                </div>               
                

            </div>            
        </div>        
    </div>    
</div> <div id="comment"></div>

<script type="text/javascript">
    // Save User 
    $('#formulaire_examen').submit( function()
        {
              var date = $('#date').val();
              var examinateur = $('#examinateur').val();
              var type_examen = $('#type_examen').val();              
              
                $.post('../control/reg_examen.php', {date:date,examinateur:examinateur,type:type_examen}, function(response)
                {
                  $('#comment').html(response); 
                  window.location.href = "index.php?page=examen";                  
                });            
                
              
           return false;         

        });

</script>

