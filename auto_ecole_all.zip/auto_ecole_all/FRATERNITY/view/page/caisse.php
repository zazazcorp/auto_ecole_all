<?php include_once '../model/Caisse.class.php' ; ?>

<div class="row">
    <div class="panel panel-default">
        <div class="panel-body">
            <ul class="nav nav-tabs">                
                <li class="active"><a href="#liste" data-toggle="tab"><h4>Entrées & Sorties</h4></a>
                </li>
                <li><a href="#recette" data-toggle="tab"><h4>Recettes</h4></a>
                </li>
                <li><a href="#compte" data-toggle="tab"><h4>Compte</h4></a>
                </li>                                                                                             
            </ul>
            <div class="tab-content">            	 

                <!-- Tab Liste E/S -->
                <div class="tab-pane fade in active" id="liste">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Listes des Toutes les Entrées et Sorties  
                            <button title="Ajouter" data-toggle="modal" data-target="#ajouter" class="btn btn-primary">Nouveau</button>                                                     
                        </div>                        
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>N°</th>
                                        <th>Type Transaction</th>
                                        <th>Somme</th>
                                        <th>Description</th>
                                        <th>Compte</th>
                                        <th>Mode transaction</th>
                                        <th>Date </th>                                        
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $caisses = Caisse::afficherAll(); $j=1; ?>
                                    <?php foreach ($caisses as $caisse) : ?>
                                    <tr class="odd gradeX">
                                        <td><?=$j; ?></td>
                                        <td>
                                          <?php if ($caisse->type == 'sortie') { ?>
                                          <button class="btn btn-danger">Sortie</button> 
                                          <?php }else{ ?>
                                          <button class="btn btn-success">Entrée</button>
                                          <?php } ?>   
                                        </td>
                                        <td><?=$caisse->somme; ?></td>
                                        <td><?=$caisse->desc; ?></td>
                                        <td><?=$caisse->compte; ?></td>
                                        <td><?=$caisse->mode; ?></td>
                                        <td><?=date('d/m/Y',strtotime($caisse->date)); ?></td>

                                        <td class="center">                                    
                                            <a title="Détail" class="btn btn-primary" href="#">
                                              <span class="fa fa-pencil"></span>
                                            </a>
                                        </td>                                        
                                    </tr>
                                    <?php $j++; ?> 
                                    <?php endforeach; ?>                                      
                                </tbody>
                            </table>                            
                        </div>
                    </div>                    
                </div>

                <!-- Tab Liste Recettes -->
                <div class="tab-pane fade" id="recette">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Toutes les Recettes
                            <button title="Date" data-toggle="modal" data-target="#date" class="btn btn-warning">Choisir une date</button>

                        </div>
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Période</th>
                                        <th>Les Entrées</th>
                                        <th>Les Sorties</th>
                                        <th>Bénéfices</th>                                      
                                    </tr>
                                </thead>
                                <tbody>                                    
                                    <tr class="odd gradeX">
                                        <td>
                                            <span class="badge badge-danger">Cet Mois</span>
                                        </td>
                                        <td>                                   
                                            <a class="btn btn-success btn-lg" href="#">
                                              <?php 

                                              $entre_moi = Caisse::entreMoi(date('Y-m-d'));
                                              echo $entre_moi[0]->total ;


                                               ?>                                              
                                            </a>
                                        </td>
                                        <td>
                                            <a class="btn btn-danger btn-lg" href="#">
                                              <?php 

                                              $sortie_moi = Caisse::sortieMoi(date('Y-m-d'));
                                              echo $sortie_moi[0]->total;

                                               ?>                                              
                                            </a>
                                        </td>
                                        <td>
                                            <a  class="btn btn-primary btn-lg" href="#">
                                              <?php
                                                echo ($entre_moi[0]->total - $sortie_moi[0]->total);
                                               ?>                                              
                                            </a>
                                        </td>                                        
                                                                                                                    
                                    </tr> 
                                    <tr class="odd gradeX">
                                        <td>
                                            <span class="badge badge-danger">Cette Année</span>
                                        </td>
                                        <td>                                           
                                            <a  class="btn btn-success btn-lg" href="#">
                                              <?php 

                                              $entre_annee = Caisse::entreAnnee(date('Y-m-d'));
                                              echo $entre_annee[0]->total;

                                               ?>                                              
                                            </a>
                                        </td>
                                        <td>
                                            <a class="btn btn-danger btn-lg" href="#">
                                              <?php 

                                              $sortie_annee = Caisse::sortieAnnee(date('Y-m-d'));
                                              echo $sortie_annee[0]->total;

                                               ?>                                              
                                            </a>
                                        </td>
                                        <td>
                                            <a  class="btn btn-primary btn-lg" href="#">
                                              <?php 
                                              echo ($entre_annee[0]->total - $sortie_annee[0]->total);                                              

                                               ?>                                              
                                            </a>
                                        </td>                                        
                                                                                                                     
                                    </tr>                                                                                                           
                                </tbody>
                            </table>                            
                        </div>
                    </div>                    
                </div>

                <!-- Tab Liste Compte -->
                <div class="tab-pane fade" id="compte">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Listes des transactions sur un compte  
                                                                                 
                        </div>                        
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>N°</th>
                                        <th>Type Transaction</th>
                                        <th>Somme</th>
                                        <th>Description</th>
                                        <th>Compte</th>
                                        <th>Mode transaction</th>
                                        <th>Date </th>                                        
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $caisses = Caisse::afficherCompte(); $j=1; ?>
                                    <?php foreach ($caisses as $caisse) : ?>
                                    <tr class="odd gradeX">
                                        <td><?=$j; ?></td>
                                        <td>
                                          <?php if ($caisse->type == 'sortie') { ?>
                                          <button class="btn btn-danger">Sortie</button> 
                                          <?php }else{ ?>
                                          <button class="btn btn-success">Entrée</button>
                                          <?php } ?>   
                                        </td>
                                        <td><?=$caisse->somme; ?></td>
                                        <td><?=$caisse->desc; ?></td>
                                        <td><?=$caisse->compte; ?></td>
                                        <td><?=$caisse->mode; ?></td>
                                        <td><?=date('d/m/Y',strtotime($caisse->date)); ?></td>

                                        <td class="center">                                    
                                            <a title="Détail" class="btn btn-primary" href="#">
                                              <span class="fa fa-pencil"></span>
                                            </a>
                                        </td>                                        
                                    </tr>
                                    <?php $j++; ?> 
                                    <?php endforeach; ?>                                      
                                </tbody>
                            </table>                            
                        </div>
                    </div>                    
                </div>


                

            </div>            
        </div>        
    </div>    
</div> 


<div id="ajouter" class="modal fade" role="dialog" > 
    <div class="modal-dialog modal-lg">
                <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Enregistrement d'une Entrée ou Sortie d'argent</h4>
                <h5 style="color: red;"> Les informations suivies d'un astérix (*) sont obligatoires </h5>
            </div>
            <div class="modal-body">
                <div class="row">
                    <form role="form" action="../control/reg_caisse.php" method="POST">   
                         <div class="form-group col-lg-4">
                           <label>Type de Transaction: <span style="color: red">*</span></label>
                           <div>
                                <select class="form-control" name="type"  required >
                                      <option value="entre" selected>Entrée d'argent</option>  
                                      <option value="sortie" >Sortie d'argent</option>
                                         
                               </select>
                           </div>
                         </div>

                         <div class="form-group col-lg-4">
                             <label>La Somme :  <span style="color: red">*</span></label>
                             <input class="form-control" type="number" name="somme" required />
                        </div>
                        <div class="form-group col-lg-4">
                             <label>Description :  <span style="color: red">*</span></label>
                             <input class="form-control" type="text" name="desc" placeholder="Description" required />
                        </div>
                       
                        <div class="form-group col-lg-4">
                             <label>Mode Transaction :  <span style="color: red">*</span></label>
                             <div>
                                <select class="form-control" name="mode" required >
                                      <option value="ESPECE" selected>ESPECE</option>  
                                      <option value="CHEQUE" >CHEQUE</option>
                                      <option value="ORANGE MONEY">ORANGE MONEY</option>
                                      <option value="MOBICASH" >MOBICASH</option>
                                      <option value="WESTERN UNION" >WESTERN UNION</option> 
                                      <option value="AUTRE" >AUTRE</option>   
                               </select>
                           </div>
                        </div>
                        <div class="form-group col-lg-4">
                             <label>Date de Transaction  : </label>
                             <input class="form-control" type="date" name="date"/>
                        </div> 

                        <div class="form-group col-lg-4">
                             <label>Destination :  <span style="color: red">*</span></label>
                             <div>
                                <select class="form-control" name="compte" required >
                                      <option value="COMPTE" selected>COMPTE</option>  
                                      <option value="AUTRE" >AUTRE</option>                           
                               </select>
                           </div>
                        </div>                              
                       
                       
                       <div class="modal-footer">
                            <input type="submit" class="btn btn-success"  name="submit" value="Valider"/>
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Annuler</button>   
                       </div>                                      
                    </form>
                </div>
            </div>               
        </div>
    </div>
</div>

<div id="date" class="modal fade" role="dialog" > 
    <div class="modal-dialog modal-lg">
                <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Voir les Entrée ou Sortie d'argent suivant la date </h4>                
            </div>
            <div class="modal-body">
                <div class="row">
                    <form role="form" action="index.php?page=de_caisse" method="POST">   
                         <div class="form-group col-lg-4">
                           <label>Choisir une date : <span style="color: red">*</span></label>
                           <input class="form-control" type="date" name="date" required />
                         </div>               
                       
                       <div class="modal-footer">
                            <input type="submit" class="btn btn-success"  name="submit" value="Valider"/>
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Annuler</button>   
                       </div>                                      
                    </form>
                </div>
            </div>               
        </div>
    </div>
</div>

