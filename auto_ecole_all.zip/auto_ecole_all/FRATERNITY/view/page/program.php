<?php 
    include_once'../model/Examen.class.php';
    include_once'../model/Eleve.class.php'; 

    include_once'../model/Programation.class.php';

    $exam = Examen::afficherOne($_GET['id_examen']);  
 ?>
<div class="col col-lg-12">
	<div class="panel-body" style="overflow: scroll;height: 700px;"> 
		<table width="100%" class="table table-striped table-bordered table-hover" id="table_id">
			<div class="panel-header">
				<h4>Liste de Tous les Elèves Programmés à cet Examen</h4>
          <div class="row">
            <div class="col-lg-3">
              <form method="post" action="../control/upload_csv.php" enctype="multipart/form-data">          
                    <input type="file" name="file" required="" >
                    <input type="hidden" name="id_examen" value="<?=$_GET['id_examen']?>">
                    <input type="submit" name="submit" class="btn btn-primary" value="Charger">         
              </form>    
              
            </div>
            <div class="col-lg-1"></div>           
            
            <div class="col-lg-8">
              <div class="row">            

              <form role="form" action="../public/pdf/program.php">
                <div class="form-group col-lg-3">
                     <label>Véhicule :  <span style="color: red">*</span></label>
                     <input class="form-control" type="text" name="vehicule"  />
                </div>

                <div class="form-group col-lg-3">
                     <label>Site :  <span style="color: red">*</span></label>
                     <input class="form-control" type="text" name="site"  />
                </div>

                <div class="form-group col-lg-3">
                     <label>N° Ecole :  <span style="color: red">*</span></label>
                     <input class="form-control" type="text" name="auto"  />
                </div>

                <div class="form-group col-lg-3">
                     <input type="hidden" name="id_examen" value="<?=$_GET['id_examen']?>">     
                     <button type="submit" class="btn btn-lg btn-warning">
                        <span class="fa fa-print"></span>
                        Imprimer
                     </button>
                </div>
              </form>



              <!-- <a href="../public/pdf/program.php?id_examen=<?=$_GET['id_examen']?>" target="_blank" class="btn btn-warning"><span class="fa fa-print"></span>
                Imprimer
              </a> --> 
              </div>             
            </div>
            
          </div>
        
			</div>
		    <thead>
		        <tr>
		            <th>N°</th>
		            <th>Nom</th>
		            <th>Prénom</th>
		            <th>Type Examen</th>
		            <th>Date d'Examen</th>
		            <th>Examinateur</th>
                <th>Agence</th>
		            <th>Action</th>
		        </tr>
		    </thead>
		    <tbody>

		    	<?php $eleves = Examen::afficherParticipantProgram($_GET['id_examen']); $j=1; ?>
                <?php foreach ($eleves as $eleve) : ?>

		      <tr>
		        <td align="center"><b><?=$j?></b></td>
		        <td align="center"><b><?=$eleve->nom ; ?></b></td>
		        <td align="center"><b><?=$eleve->prenom ; ?></b></td>
		        <td align="center"><b><?=$eleve->type ; ?></b></td>
		        <td align="center"><b><?=$eleve->date_examen ; ?></b></td>            
		        <td align="center"><b><?=$eleve->examinateur ; ?></b></td>
            <td align="center">Siège</td>
		        <td>		        	
		        	<!-- <a title="Détail" class="btn btn-primary" 
		        	   href="index.php?page=eleve_examen&id_eleve=<?=$eleve->id_eleve ; ?>">
		        		<i class="fa fa-pencil"></i>
		        	</a> -->
		        	   <!-- Modal must dynam and script -->
                    <?php if ($_SESSION['fonction'] == 'administrateur') {  ?>
                    <button title="Supprimer" type="button" class="btn btn-danger" data-toggle="modal" data-target="<?='#mod'.$eleve->id_eleve;?>">
                      <span class="fa fa-trash"></span>
                    </button>
                    <?php } ?>

                    <!-- Modal -->
                    <div class="modal fade" id="<?='mod'.$eleve->id_eleve;?>" tabindex="-1" role="dialog"  aria-hidden="true">
                      <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" >
                              Supprimer <b><?=$eleve->nom.' '.$eleve->prenom; ?></b>
                            </h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <form method="post" action="../control/del_eleve_program.php">
                              <div class="modal-body">                           
                                <input type="hidden" name="id_program" value="<?=$eleve->id_program;?>">
                                <input type="hidden" name="id_examen" value="<?=$eleve->id_examen;?>">
                                <button class="btn btn-danger">
                                <h3>
                                    Voulez vous vraiment supprimer cet élève ?                                                 
                                </h3>
                                </button>                                      
                              </div>
                              <div class="modal-footer">                           
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">NON</button>
                                <button type="submit" name="submit" class="btn btn-primary">OUI</button>
                              </div>                                                      
                          </form>
                        </div>
                      </div>
                    </div>  	
		        </td>		        		        
		      </tr>
		      <?php $j++; endforeach; ?>

          <!-- Programation -->
          <?php $programs = Programation::afficher($_GET['id_examen']); ?>
                <?php foreach ($programs as $program) : ?>

                    <tr>
                      <td align="center"><b><?=$j?></b></td>
                      <td align="center"><b><?=$program->nom ; ?></b></td>
                      <td align="center"><b><?=$program->prenom ; ?></b></td>
                      <td align="center"></td>
                      <td align="center"></td>
                      <td align="center"></td>
                      <td align="center"><?=$program->agence ; ?></td>                      
                      <td>              
                        <!-- <a title="Détail" class="btn btn-primary" 
                           href="index.php?page=eleve_examen&id_eleve=<?=$eleve->id_eleve ; ?>">
                          <i class="fa fa-pencil"></i>
                        </a> -->
                           <!-- Modal must dynam and script -->
                              <?php if ($_SESSION['fonction'] == 'administrateur') {  ?>
                              <button title="Supprimer" type="button" class="btn btn-danger" data-toggle="modal" data-target="<?='#mod'.$program->id_programation;?>">
                                <span class="fa fa-trash"></span>
                              </button>
                              <?php } ?>

                              <!-- Modal -->
                              <div class="modal fade" id="<?='mod'.$program->id_programation;?>" tabindex="-1" role="dialog"  aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title" >
                                        Supprimer <b><?=$program->nom.' '.$program->prenom; ?></b>
                                      </h5>
                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                      </button>
                                    </div>
                                    <form method="post" action="../control/del_programation.php">
                                        <div class="modal-body">                           
                                          <input type="hidden" name="id_programation" value="<?=$program->id_programation;?>">
                                          <input type="hidden" name="id_examen" value="<?=$_GET['id_examen'];?>">
                                          <button class="btn btn-danger">
                                          <h3>
                                              Voulez vous vraiment supprimer cet élève ?                                                 
                                          </h3>
                                          </button>                                      
                                        </div>
                                        <div class="modal-footer">                           
                                          <button type="button" class="btn btn-secondary" data-dismiss="modal">NON</button>
                                          <button type="submit" name="submit" class="btn btn-primary">OUI</button>
                                        </div>                                                      
                                    </form>
                                  </div>
                                </div>
                              </div>    
                      </td>                       
                    </tr>

                <?php $j++; endforeach; ?>


		    </tbody>
		</table>
	</div>
</div>

