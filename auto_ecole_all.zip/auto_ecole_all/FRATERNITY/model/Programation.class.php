<?php

include_once "Model.class.php";

/**
 * Classe  Dossier. 
 *
 * @version 1.0
 * @author zcorp & edotensei
 */

 class Programation extends Model
 {

    public static function afficher($id)
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM programation WHERE examen="'.$id.'" ORDER BY nom,prenom ');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Programation');

        return $donne;        
    }

    public static function updateOne($champ,$id,$value)
    {
        $con = parent::getPDO();
        $ins = $con->prepare("UPDATE dossier SET $champ=? WHERE id_dossier=?");
        $ins->execute(array($value, $id ));
    }

    public static function supprimerEleveProgram($id)
    {
        $con = parent::getPDO();
        
        $sup = $con->prepare('DELETE FROM programation WHERE id_programation=?');
        $sup->execute(array($id));
    }

    public static function InitEleve($id)
    {
        $con = parent::getPDO();
        $ins = $con->prepare('INSERT INTO dossier VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
        $ins->execute(array(NULL,NULL,0,0,0,0,0,0,'',NULL,'','',0,$id ));
    }

    public static function supprimer($id)
    {
        $con = parent::getPDO();
        
        $sup = $con->prepare('DELETE FROM programation WHERE id_programation=?');
        $sup->execute(array($id));
        
        
    }

     //Importation du fichier csv dans la base de données
    public static function import($file,$id_exam){

        $con= parent::getPDO();
        
       //Le chemin d'acces a ton fichier sur le serveur
    $fichier = fopen($file, "r");
 
	//tant qu'on est pas a la fin du fichier :
	while (!feof($fichier))
	{
        // On recupere toute la ligne
        $uneLigne = addslashes(fgets($fichier));
        //On met dans un tableau les differentes valeurs trouvés (ici séparées par un ';')
        $tableauValeurs = explode(';', $uneLigne);

        
        // On crée la requete pour inserer les donner 
        $sql="INSERT INTO programation VALUES (?,?,?,?,?,?,?)";

        if(feof($fichier))
            break;
        else
        {
            $req = $con->prepare($sql);
            if ($tableauValeurs[0] != 'NOM' AND $tableauValeurs[1] != 'PRENOMS' AND
                $tableauValeurs[0] != '' AND $tableauValeurs[1] != '') {
            	# code...
            	$req->execute(array(null,$tableauValeurs[0], $tableauValeurs[1], 
            	$tableauValeurs[2], $tableauValeurs[3], $tableauValeurs[4], $id_exam ));
            }
            
            // la ligne est finie donc on passe a la ligne suivante (boucle)
        }
    //vérification et envoi d'une réponse à l'utilisateur
    
     }
     if($req)

        return 1;

    else

        return 0;
        
    }



 }