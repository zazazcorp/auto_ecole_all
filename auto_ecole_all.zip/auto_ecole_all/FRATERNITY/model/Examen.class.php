<?php

include_once "Model.class.php";

/**
 * Classe  Examen. 
 *
 * @version 1.0
 * @author zcorp & edotensei
 */

 class Examen extends Model
 {

    public static function register($data)
    {
        $con = parent::getPDO();
        $ins = $con->prepare('INSERT INTO examen VALUES(?,?,?,?)');
        $ins->execute(array(null, $data['date'], $data['examinateur'], $data['type'] ));
    }

    public static function registerProgram($data)
    {
        $con = parent::getPDO();
        $ins = $con->prepare('INSERT INTO program VALUES(?,?,?)');
        $ins->execute(array(null, $data['eleve'], $data['examen'] ));
    }

    public static function afficherProgram($id)
    {
        $con = parent::getPDO();        
        $ins = $con->query("SELECT count(*) AS nombre FROM examen e, program p WHERE e.id_examen=p.examen AND id_examen=$id  ORDER BY date_examen DESC");          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Examen');

        return $donne;        
    }

    public static function registerExamenEleve($data)
    {
        $con = parent::getPDO();
        $ins = $con->prepare('INSERT INTO examen_eleve VALUES(?,?,?,?)');
        $ins->execute(array(null, $data['id_eleve'], $data['id_examen'], $data['resultat'] ));
    }

    public static function afficher()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM examen ORDER BY date_examen DESC');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Examen');

        return $donne;        
    }

    public static function afficherOne($id)
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM eleve WHERE id_eleve="'.$id.'"');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Eleve');

        return $donne;        
    }

    public static function supprimerEleveProgram($id)
    {
        $con = parent::getPDO();
        
        $sup = $con->prepare('DELETE FROM program WHERE id_program=?');
        $sup->execute(array($id));
    }

    public static function afficherExamenOne($id)
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM examen WHERE id_examen="'.$id.'"');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Examen');

        return $donne;        
    }

    public static function afficherExamen()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM examen ORDER BY date_examen DESC LIMIT 0,9');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Examen');

        return $donne;        
    }

    public static function afficherParticipant($id)
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT COUNT(eleve) as participant FROM examen e, examen_eleve ex 
                            WHERE e.id_examen = ex.examen 
                            AND ex.examen = "'.$id.'" ');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Examen');

        return $donne;        
    }

    public static function afficherParticipantExamenOne($id)
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM eleve e, examen ex, examen_eleve exe 
                            WHERE e.id_eleve = exe.eleve 
                            AND ex.id_examen = exe.examen
                            AND exe.examen = "'.$id.'"
                            ORDER BY nom');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Eleve');

        return $donne;        
    }

    public static function afficherParticipantProgram($id)
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM eleve e, examen ex, program p
                            WHERE e.id_eleve = p.eleve 
                            AND ex.id_examen = p.examen
                            AND p.examen = "'.$id.'"
                            ORDER BY nom');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Eleve');

        return $donne;        
    }


    public static function affichertExamenEleve($type_examen,$id_eleve)
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM eleve e, examen ex, examen_eleve exe 
                            WHERE e.id_eleve = exe.eleve 
                            AND ex.id_examen = exe.examen
                            AND exe.eleve = "'.$id_eleve.'"
                            AND ex.type = "'.$type_examen.'"
                            ORDER BY ex.date_examen DESC');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Eleve');

        return $donne;        
    }

    public static function supprimer($id)
    {
        $con = parent::getPDO();
        
        $sup = $con->prepare('DELETE FROM examen_eleve WHERE examen=?');
        $sup->execute(array($id));

        $sup = $con->prepare('DELETE FROM program WHERE examen=?');
        $sup->execute(array($id));

        $sup = $con->prepare('DELETE FROM examen WHERE id_examen=?');
        $sup->execute(array($id));       
        
        
    }

    public static function modifier($data = array())
    {
        $con = parent::getPDO();
        $ins = $con->prepare('UPDATE examen SET date_examen =?, examinateur=?, type=? WHERE id_examen=?');
        $ins->execute(array($data['date'],$data['examinateur'], $data['type'], $data['id_examen'] ));
    }

 }