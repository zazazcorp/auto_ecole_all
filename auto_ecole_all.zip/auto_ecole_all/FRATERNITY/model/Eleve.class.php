<?php

include_once "Model.class.php";

/**
 * Classe  Eleve. 
 *
 * @version 1.0
 * @author zcorp & edotensei
 */

 class Eleve extends Model
 {

    /**AJouter un Elève avec toutes les infos
     * @param $data(array)
     */
    public static function register($data)
    {
        $con = parent::getPDO();
        $ins = $con->prepare('INSERT INTO eleve VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
        $ins->execute(array(null, $data['nom'], $data['prenom'], $data['contact'], 
            $data['profession'], $data['adresse'], $data['dob'], $data['sexe'],
            $data['dor'],$data['pob'], $data['categorie'], $data['solde'], $data['forfait'],
            $data['statut']));
    }

    /**Afficher Tous les  Elèves avec toutes les infos ordonnés par le nom
     * 
     */ 
    public static function afficher()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM eleve ORDER BY nom,prenom');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Eleve');

        return $donne;        
    }
    

    /*Afficher les 10 derniers Inscrits*/
    public static function afficher10dernier()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM eleve WHERE statut=1 ORDER BY dor DESC LIMIT 10');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Eleve');

        return $donne;        
    }

    public static function afficherImpaye()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM eleve WHERE statut=1 AND id_eleve NOT IN (SELECT p.eleve FROM eleve e, paiement p WHERE e.id_eleve = p.eleve) ORDER BY nom,prenom');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Eleve');

        return $donne;        
    }

    public static function afficherPaiement()
    {       
        
        $con = parent::getPDO();
        $ins = $con->query('SELECT nom,prenom,id_eleve,SUM(somme) 
            AS some, solde,categorie,contact, forfait 
            FROM eleve e, paiement p 
            WHERE e.id_eleve=p.eleve
            AND statut=1  
            GROUP BY e.id_eleve ORDER BY e.nom,e.prenom');
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Eleve'); 
        return $donne;              
    }


    public static function afficherSolde()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * from eleve e, paiement p where e.id_eleve=p.eleve and e.solde = (select sum(p.somme) from eleve e, paiement p where e.id_eleve=p.eleve)');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Eleve');

        return $donne;        
    }

    public static function afficherCours()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM eleve WHERE statut=1 ORDER BY nom,prenom');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Eleve');

        return $donne;        
    }

    public static function afficherStatut()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM eleve WHERE statut=0 ORDER BY nom,prenom');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Eleve');

        return $donne;        
    }
    

    /*AFicher un élève*/
    public static function afficherOne($id)
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM eleve WHERE id_eleve="'.$id.'"');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Eleve');

        return $donne;        
    }

     /*AFicher Accueil Nombre élève*/
    public static function countAll()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT COUNT(id_eleve) as nombre FROM eleve ');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Eleve');
        return $donne;        
    }

    /*AFicher Accueil Nombre élève*/
    public static function countCours()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT COUNT(id_eleve) as nombre FROM eleve WHERE statut=1 ');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Eleve');
        return $donne;        
    }

    /*AFicher Accueil Nombre élève*/
    public static function countPermi()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT COUNT(id_eleve) as nombre FROM eleve WHERE statut=0 ');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Eleve');
        return $donne;        
    }

    /*
     * Fonction static Modification
     * @param array, $_POST
     */
    public static function modifier($data = array())
    {
        $con = parent::getPDO();
        $ins = $con->prepare('UPDATE eleve SET nom=?, prenom=?, contact=?,
                              profession=? , adresse=?, dob=?, pob=?, sexe=?, dor=?, categorie=?,
                              solde=?, forfait=?, statut=? WHERE id_eleve=?');
        $ins->execute(array($data['nom'], $data['prenom'], $data['contact'],
                            $data['profession'], $data['adresse'], $data['dob'], $data['pob'],
                            $data['sexe'], $data['dor'], $data['categorie'], $data['solde'],
                            $data['forfait'], $data['statut'], $data['id_eleve'] ));
    }

    /*
     * Fonction static Supprimer
     * @param array, $_POST
     */
    public static function supprimer($id)
    {
        $con = parent::getPDO();
        
        $sup = $con->prepare('DELETE FROM paiement WHERE eleve=?');
        $sup->execute(array($id));

        $sup = $con->prepare('DELETE FROM dossier WHERE eleve=?');
        $sup->execute(array($id));

        $sup = $con->prepare('DELETE FROM examen_eleve WHERE eleve=?');
        $sup->execute(array($id));

        $sup = $con->prepare('DELETE FROM program WHERE eleve=?');
        $sup->execute(array($id));

        $sup = $con->prepare('DELETE FROM eleve WHERE id_eleve=?');
        $sup->execute(array($id));
        
        
    }
 }