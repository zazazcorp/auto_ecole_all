<?php 

include_once "Model.class.php";

/**
 * Classe  Caisse. 
 *
 * @version 1.0
 * @author zcorp & edotensei
 */

 class Caisse extends Model
 {
 	public static function register($data)
    {
        $con = parent::getPDO();
        $ins = $con->prepare('INSERT INTO caisse VALUES(?,?,?,?,?,?,?)');
        $ins->execute(array(NULL,$data['type'], $data['somme'], $data['desc'], $data['compte'], 
            $data['mode'], $data['date'] ));
    }

    public static function afficherAll()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM caisse ORDER BY date ');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Caisse');

        return $donne;        
    }

    public static function afficherCompte()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM caisse
                            WHERE compte="COMPTE" ORDER BY date ');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Caisse');

        return $donne;        
    }

    public static function entreMoi($date)
    {
        $con = parent::getPDO();
        $moi = date_parse($date)['month'];
        $annee = date_parse($date)['year'];
        $start_int = $annee.'-'.$moi.'-01';
        $end_int = $annee.'-'.$moi.'-31';         
        $ins = $con->query(' SELECT SUM(somme) AS total 
        	                 FROM caisse 
        	                 WHERE type="entre"
        	                 AND date 
        	                 BETWEEN "'.$start_int.'" AND "'.$end_int.'" ');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Caisse');

        return $donne;        
    }

    public static function sortieMoi($date)
    {
        $con = parent::getPDO();
        $moi = date_parse($date)['month'];
        $annee = date_parse($date)['year'];
        $start_int = $annee.'-'.$moi.'-01';
        $end_int = $annee.'-'.$moi.'-31';         
        $ins = $con->query(' SELECT SUM(somme) AS total 
        	                 FROM caisse 
        	                 WHERE type="sortie"
        	                 AND date 
        	                 BETWEEN "'.$start_int.'" AND "'.$end_int.'" ');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Caisse');

        return $donne;        
    }

    public static function entreAnnee($date)
    {
        $con = parent::getPDO();        
        $annee = date_parse($date)['year'];
        $start_int = $annee.'-01-01';
        $end_int = $annee.'-12-31';         
        $ins = $con->query(' SELECT SUM(somme) AS total 
        	                 FROM caisse 
        	                 WHERE type="entre"
        	                 AND date 
        	                 BETWEEN "'.$start_int.'" AND "'.$end_int.'" ');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Caisse');

        return $donne;        
    }

    public static function sortieAnnee($date)
    {
        $con = parent::getPDO();        
        $annee = date_parse($date)['year'];
        $start_int = $annee.'-01-01';
        $end_int = $annee.'-12-31';         
        $ins = $con->query(' SELECT SUM(somme) AS total 
        	                 FROM caisse 
        	                 WHERE type="sortie"
        	                 AND date 
        	                 BETWEEN "'.$start_int.'" AND "'.$end_int.'" ');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Caisse');

        return $donne;        
    }

    public static function totalEntree($date)
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT SUM(somme) as total FROM paiement WHERE eleve="'.$id.'"');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Paiement');

        return $donne;        
    }

    public static function totalSortie($date)
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT SUM(somme) as total FROM caisse WHERE eleve="'.$id.'"');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Paiement');

        return $donne;        
    }

    public static function annee(){


    }

 }