<?php

include_once "Model.class.php";

/**
 * Classe  Paiement. 
 *
 * @version 1.0
 * @author zcorp & edotensei
 */

 class Paiement extends Model
 {

    public static function register($data)
    {
        $con = parent::getPDO();
        $ins = $con->prepare('INSERT INTO paiement VALUES(?,?,?,?,?,?)');
        $ins->execute(array(null,$data['numero'], $data['date_paiement'], $data['somme'], $data['type'], 
            $data['id'] ));
    }

    public static function afficher($id)
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM paiement WHERE eleve="'.$id.'" ORDER BY date_paiement');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Paiement');

        return $donne;        
    }

    public static function genererNumbRecu()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT COUNT(id_paiement) AS nombre FROM paiement');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Paiement');

        return $donne;        
    }

    public static function afficherEleve($id)
    {
        $con = parent::getPDO();        
        $ins = $con->query("SELECT * FROM paiement p, eleve e 
                            WHERE e.id_eleve=p.eleve
                            AND p.id_paiement = $id
                            AND statut=1");          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Paiement');

        return $donne;        
    }

   

    public static function afficherTotalOne($id)
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT SUM(somme) as total FROM paiement WHERE eleve="'.$id.'"');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Paiement');

        return $donne;        
    }

    public static function afficherSomModif($id)
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT somme  FROM paiement WHERE id_paiement="'.$id.'"');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Paiement');

        return $donne;        
    }

    /*
     * Fonction static Modification
     * @param array, $_POST
     */
    public static function modifier($data = array())
    {
        $con = parent::getPDO();
        $ins = $con->prepare('UPDATE paiement SET numero =?, date_paiement=?, somme=?, type=? WHERE id_paiement=?');
        $ins->execute(array($data['numero'],$data['date_paiement'], $data['somme'], $data['type'],
                            $data['id_paiement'] ));
    }

    /*
     * Fonction static Supprimer
     * @param array, $_POST
     */
    public static function supprimer($id)
    {
        $con = parent::getPDO();
        
        $sup = $con->prepare('DELETE FROM paiement WHERE id_paiement=?');
        $sup->execute(array($id));
        
        
    }

   


 }