<?php 

/*
 * Les Variables globales pour configurer le système 
 * Les informations sur votre Auto Ecole 
 */

$config = array(
    'NOM' => 'Fraternity Auto Ecole',
    'NUMERO' => '+(226) 25-65-01-92',
    'EMAIL' => 'kanimaxe@yahoo.fr',
    'LOCATION' => 'Ouagadougou 04, O4 BP 498',
    'ADRESSE' => '',    
);



?>