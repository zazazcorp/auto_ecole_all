-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Lun 11 Novembre 2019 à 08:34
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `auto_ecole_dev`
--

-- --------------------------------------------------------

--
-- Structure de la table `agence`
--

CREATE TABLE IF NOT EXISTS `agence` (
  `id_agence` int(10) NOT NULL AUTO_INCREMENT,
  `entete` text,
  `libele` varchar(100) DEFAULT NULL,
  `ville` varchar(100) DEFAULT NULL,
  `adresse` varchar(255) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_agence`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `agence`
--

INSERT INTO `agence` (`id_agence`, `entete`, `libele`, `ville`, `adresse`, `contact`) VALUES
(1, NULL, 'TEGAWENDE PISSY', 'OUAGADOUGOU', 'OUAGA PISSY', '78767574');

-- --------------------------------------------------------

--
-- Structure de la table `bordereau`
--

CREATE TABLE IF NOT EXISTS `bordereau` (
  `id_bordereau` int(11) NOT NULL AUTO_INCREMENT,
  `date_depot` date NOT NULL,
  `eleve` int(11) NOT NULL,
  PRIMARY KEY (`id_bordereau`),
  KEY `eleve` (`eleve`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `bordereau`
--

INSERT INTO `bordereau` (`id_bordereau`, `date_depot`, `eleve`) VALUES
(1, '2019-11-14', 4),
(2, '2019-11-14', 4);

-- --------------------------------------------------------

--
-- Structure de la table `bordereau_csv`
--

CREATE TABLE IF NOT EXISTS `bordereau_csv` (
  `id_bord_csv` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `pob` varchar(255) NOT NULL,
  `agence` varchar(255) NOT NULL,
  `date_d` varchar(20) NOT NULL,
  PRIMARY KEY (`id_bord_csv`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=72 ;

--
-- Contenu de la table `bordereau_csv`
--

INSERT INTO `bordereau_csv` (`id_bord_csv`, `nom`, `prenom`, `dob`, `pob`, `agence`, `date_d`) VALUES
(51, 'YAO', 'ISSA', '20/04/1995', 'ABIDJAN', 'COCODY\r\n', '2019-11-05'),
(52, 'ALI', 'MADI', '30/03/2018', 'OUAGA', 'TOGO\r\n', '2019-11-05'),
(53, 'ZANNE', 'ISSOUF', '10/02/1999', 'DABA', 'MALI\r\n', '2019-11-05'),
(54, 'OUEDRAOGO', 'SOULE', '10/06/1685', 'PO', 'TAMPOUY\r\n', '2019-11-05'),
(55, 'SEMDE', 'AROUNA', '17/10/2010', 'MALI', 'KADIOGO\r\n', '2019-11-05'),
(56, 'YAO', 'ISSA', '20/04/1995', 'ABUDJAN', 'COCODY\r\n', '2019-11-05'),
(57, 'ALI', 'MADI', '30/03/2018', 'OUAGA', 'TOGO\r\n', '2019-11-05'),
(58, 'ZANNE', 'ISSOUF', '10/02/1999', 'DABA', 'MALI\r\n', '2019-11-05'),
(59, 'OUEDRAOGO', 'SOULE', '10/06/1685', 'PO', 'TAMPOUY\r\n', '2019-11-05'),
(60, 'SEMDE', 'AROUNA', '17/10/2010', 'MALI', 'KADIOGO\r\n', '2019-11-05'),
(61, 'YAO', 'ISSA', '20/04/1995', 'ABUDJAN', 'COCODY\r\n', '2019-11-12'),
(62, 'ALI', 'MADI', '30/03/2018', 'OUAGA', 'TOGO\r\n', '2019-11-12'),
(63, 'ZANNE', 'ISSOUF', '10/02/1999', 'DABA', 'MALI\r\n', '2019-11-12'),
(64, 'OUEDRAOGO', 'SOULE', '10/06/1685', 'PO', 'TAMPOUY\r\n', '2019-11-12'),
(65, 'SEMDE', 'AROUNA', '17/10/2010', 'MALI', 'KADIOGO\r\n', '2019-11-12'),
(66, '111', '2222', '3333', '4444', '555\r\n', '2019-11-12'),
(67, '22222', '33333', '04/11/3116', '555555', '666666\r\n', '2019-11-12'),
(68, '4444', '4444455', '12/10/4029', '554433', '223233\r\n', '2019-11-12'),
(69, '76554', 'uykyttr', '06/12/1914', 'fhgfhg', '65656r\r\n', '2019-11-12'),
(70, 'ytftrerdcfdt', '576576fgf', '6565', '56565', '65656556535\r\n', '2019-11-12'),
(71, 'cgfdtf', 'trrytfctretr', 'rtgfdtredc', 'fcfgdtd', 'cfrtdtddfgd\r\n', '2019-11-12');

-- --------------------------------------------------------

--
-- Structure de la table `caisse`
--

CREATE TABLE IF NOT EXISTS `caisse` (
  `id_caisse` int(10) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) DEFAULT NULL,
  `somme` float DEFAULT NULL,
  `desc` text,
  `compte` varchar(100) DEFAULT NULL,
  `mode` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `agence` int(11) NOT NULL,
  PRIMARY KEY (`id_caisse`),
  KEY `agence` (`agence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `dossier`
--

CREATE TABLE IF NOT EXISTS `dossier` (
  `id_dossier` int(10) NOT NULL AUTO_INCREMENT,
  `date_depo` date DEFAULT NULL,
  `extrait` int(2) DEFAULT '0',
  `cnib` int(2) DEFAULT '0',
  `auto_parentale` int(2) DEFAULT '0',
  `quitance` int(2) DEFAULT '0',
  `ost` int(2) DEFAULT '0',
  `act_mariage` int(2) DEFAULT '0',
  `permi_provisoir` varchar(100) DEFAULT 'Aucune',
  `date_sorti` date DEFAULT NULL,
  `agence` varchar(100) DEFAULT NULL,
  `commentaire` text,
  `photo` varchar(30) DEFAULT NULL,
  `eleve` int(10) NOT NULL,
  PRIMARY KEY (`id_dossier`),
  KEY `eleve` (`eleve`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `dossier`
--

INSERT INTO `dossier` (`id_dossier`, `date_depo`, `extrait`, `cnib`, `auto_parentale`, `quitance`, `ost`, `act_mariage`, `permi_provisoir`, `date_sorti`, `agence`, `commentaire`, `photo`, `eleve`) VALUES
(1, NULL, 0, 0, 0, 0, 0, 0, '', NULL, '', '', '0', 4);

-- --------------------------------------------------------

--
-- Structure de la table `eleve`
--

CREATE TABLE IF NOT EXISTS `eleve` (
  `id_eleve` int(10) NOT NULL AUTO_INCREMENT,
  `nom` varchar(30) DEFAULT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `contact` varchar(30) DEFAULT NULL,
  `profession` varchar(100) DEFAULT NULL,
  `adresse` varchar(100) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `sexe` varchar(15) DEFAULT NULL,
  `dor` date NOT NULL,
  `pob` varchar(100) DEFAULT NULL,
  `categorie` varchar(30) DEFAULT NULL,
  `solde` float DEFAULT NULL,
  `forfait` varchar(100) DEFAULT NULL,
  `statut` int(2) NOT NULL DEFAULT '1',
  `agence` int(11) NOT NULL,
  PRIMARY KEY (`id_eleve`),
  KEY `agence` (`agence`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `eleve`
--

INSERT INTO `eleve` (`id_eleve`, `nom`, `prenom`, `contact`, `profession`, `adresse`, `dob`, `sexe`, `dor`, `pob`, `categorie`, `solde`, `forfait`, `statut`, `agence`) VALUES
(4, 'ZANNE', 'Issouf', '676666', 'ELEVE', 'GARA', '2019-11-26', 'masculin', '2019-11-07', 'OUAGADOUGOU', 'D', 12340000, 'normal', 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `examen`
--

CREATE TABLE IF NOT EXISTS `examen` (
  `id_examen` int(10) NOT NULL AUTO_INCREMENT,
  `date_examen` date DEFAULT NULL,
  `examinateur` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_examen`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `examen`
--

INSERT INTO `examen` (`id_examen`, `date_examen`, `examinateur`, `type`) VALUES
(1, '2019-10-22', '', 'code'),
(2, '2019-11-09', '', 'crenau');

-- --------------------------------------------------------

--
-- Structure de la table `examen_eleve`
--

CREATE TABLE IF NOT EXISTS `examen_eleve` (
  `id_examen_eleve` int(10) NOT NULL AUTO_INCREMENT,
  `eleve` int(10) NOT NULL,
  `examen` int(10) NOT NULL,
  `resultat` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_examen_eleve`),
  KEY `eleve` (`eleve`),
  KEY `examen` (`examen`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `examen_eleve`
--

INSERT INTO `examen_eleve` (`id_examen_eleve`, `eleve`, `examen`, `resultat`) VALUES
(1, 4, 2, 'ajourne');

-- --------------------------------------------------------

--
-- Structure de la table `paiement`
--

CREATE TABLE IF NOT EXISTS `paiement` (
  `id_paiement` int(10) NOT NULL AUTO_INCREMENT,
  `numero` varchar(200) DEFAULT NULL,
  `date_paiement` date NOT NULL,
  `somme` float DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `eleve` int(10) NOT NULL,
  PRIMARY KEY (`id_paiement`),
  KEY `eleve` (`eleve`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `paiement`
--

INSERT INTO `paiement` (`id_paiement`, `numero`, `date_paiement`, `somme`, `type`, `eleve`) VALUES
(1, 'RSO-1', '2019-11-06', 55555, '2E VERSEMENT', 4),
(2, 'TZP-2', '2019-11-14', 666, '3E VERSMENT', 4);

-- --------------------------------------------------------

--
-- Structure de la table `program`
--

CREATE TABLE IF NOT EXISTS `program` (
  `id_program` int(10) NOT NULL AUTO_INCREMENT,
  `eleve` int(10) NOT NULL,
  `examen` int(10) NOT NULL,
  PRIMARY KEY (`id_program`),
  KEY `eleve` (`eleve`),
  KEY `examen` (`examen`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `program`
--

INSERT INTO `program` (`id_program`, `eleve`, `examen`) VALUES
(1, 4, 2),
(2, 4, 1);

-- --------------------------------------------------------

--
-- Structure de la table `programation`
--

CREATE TABLE IF NOT EXISTS `programation` (
  `id_programation` int(10) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) DEFAULT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `dob` varchar(30) DEFAULT NULL,
  `pob` varchar(100) DEFAULT NULL,
  `agence` varchar(100) DEFAULT NULL,
  `examen` int(10) NOT NULL,
  PRIMARY KEY (`id_programation`),
  KEY `examen` (`examen`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=33 ;

--
-- Contenu de la table `programation`
--

INSERT INTO `programation` (`id_programation`, `nom`, `prenom`, `dob`, `pob`, `agence`, `examen`) VALUES
(1, 'YAO', 'ISSA', '20/04/1995', 'ABUDJAN', 'COCODY\r\n', 1),
(2, 'ALI', 'MADI', '30/03/2018', 'OUAGA', 'TOGO\r\n', 1),
(3, 'ZANNE', 'ISSOUF', '10/02/1999', 'DABA', 'MALI\r\n', 1),
(4, 'OUEDRAOGO', 'SOULE', '10/06/1685', 'PO', 'TAMPOUY\r\n', 1),
(6, 'YAO', 'ISSA', '20/04/1995', 'ABIDJAN', 'COCODY\r\n', 1),
(7, 'ALI', 'MADI', '30/03/2018', 'OUAGA', 'TOGO\r\n', 1),
(8, 'ZANNE', 'ISSOUF', '10/02/1999', 'DABA', 'MALI\r\n', 1),
(9, 'OUEDRAOGO', 'SOULE', '10/06/1685', 'PO', 'TAMPOUY\r\n', 1),
(10, 'SEMDE', 'AROUNA', '17/10/2010', 'MALI', 'KADIOGO\r\n', 1),
(22, 'YAO', 'ISSA', '20/04/1995', 'ABUDJAN', 'COCODY\r\n', 2),
(23, 'ALI', 'MADI', '30/03/2018', 'OUAGA', 'TOGO\r\n', 2),
(24, 'ZANNE', 'ISSOUF', '10/02/1999', 'DABA', 'MALI\r\n', 2),
(25, 'OUEDRAOGO', 'SOULE', '10/06/1685', 'PO', 'TAMPOUY\r\n', 2),
(26, 'SEMDE', 'AROUNA', '17/10/2010', 'MALI', 'KADIOGO\r\n', 2),
(27, '111', '2222', '3333', '4444', '555\r\n', 2),
(28, '22222', '33333', '04/11/3116', '555555', '666666\r\n', 2),
(29, '4444', '4444455', '12/10/4029', '554433', '223233\r\n', 2),
(30, '76554', 'uykyttr', '06/12/1914', 'fhgfhg', '65656r\r\n', 2),
(31, 'ytftrerdcfdt', '576576fgf', '6565', '56565', '65656556535\r\n', 2),
(32, 'cgfdtf', 'trrytfctretr', 'rtgfdtredc', 'fcfgdtd', 'cfrtdtddfgd\r\n', 2);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id_user` int(10) NOT NULL AUTO_INCREMENT,
  `nom_user` varchar(100) DEFAULT NULL,
  `prenom_user` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `fonction` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`id_user`, `nom_user`, `prenom_user`, `username`, `password`, `fonction`) VALUES
(13, 'admin', 'admin', 'admin', 'zcorp', 'administrateur');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `bordereau`
--
ALTER TABLE `bordereau`
  ADD CONSTRAINT `bordereau_ibfk_1` FOREIGN KEY (`eleve`) REFERENCES `eleve` (`id_eleve`);

--
-- Contraintes pour la table `caisse`
--
ALTER TABLE `caisse`
  ADD CONSTRAINT `fk_ac` FOREIGN KEY (`agence`) REFERENCES `agence` (`id_agence`);

--
-- Contraintes pour la table `dossier`
--
ALTER TABLE `dossier`
  ADD CONSTRAINT `dossier_ibfk_1` FOREIGN KEY (`eleve`) REFERENCES `eleve` (`id_eleve`);

--
-- Contraintes pour la table `eleve`
--
ALTER TABLE `eleve`
  ADD CONSTRAINT `fk_54546546` FOREIGN KEY (`agence`) REFERENCES `agence` (`id_agence`);

--
-- Contraintes pour la table `examen_eleve`
--
ALTER TABLE `examen_eleve`
  ADD CONSTRAINT `examen_eleve_ibfk_1` FOREIGN KEY (`eleve`) REFERENCES `eleve` (`id_eleve`),
  ADD CONSTRAINT `examen_eleve_ibfk_2` FOREIGN KEY (`examen`) REFERENCES `examen` (`id_examen`);

--
-- Contraintes pour la table `paiement`
--
ALTER TABLE `paiement`
  ADD CONSTRAINT `paiement_ibfk_1` FOREIGN KEY (`eleve`) REFERENCES `eleve` (`id_eleve`);

--
-- Contraintes pour la table `program`
--
ALTER TABLE `program`
  ADD CONSTRAINT `program_ibfk_1` FOREIGN KEY (`eleve`) REFERENCES `eleve` (`id_eleve`),
  ADD CONSTRAINT `program_ibfk_2` FOREIGN KEY (`examen`) REFERENCES `examen` (`id_examen`);

--
-- Contraintes pour la table `programation`
--
ALTER TABLE `programation`
  ADD CONSTRAINT `fk_PE` FOREIGN KEY (`examen`) REFERENCES `examen` (`id_examen`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
