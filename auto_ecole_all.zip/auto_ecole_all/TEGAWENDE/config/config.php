<?php 

/*
 * Les Variables globales pour configurer le système 
 * Les informations sur votre Auto Ecole 
 */

$config = array(
    'NOM' => 'Tegawende Auto Ecole',
    'NUMERO' => '+(226) 25-00-00-00',
    'EMAIL' => 'tegawende@yahoo.fr',
    'LOCATION' => 'Ouagadougou 01, O1 BP 000',
    'ADRESSE' => '',    
);



?>