-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Sam 19 Octobre 2019 à 14:10
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `auto_ecole_dev`
--

-- --------------------------------------------------------

--
-- Structure de la table `caisse`
--

CREATE TABLE IF NOT EXISTS `caisse` (
  `id_caisse` int(10) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) DEFAULT NULL,
  `somme` float DEFAULT NULL,
  `desc` text,
  `compte` varchar(100) DEFAULT NULL,
  `mode` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id_caisse`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

-- --------------------------------------------------------

--
-- Structure de la table `dossier`
--

CREATE TABLE IF NOT EXISTS `dossier` (
  `id_dossier` int(10) NOT NULL AUTO_INCREMENT,
  `date_depo` date DEFAULT NULL,
  `extrait` int(2) DEFAULT '0',
  `cnib` int(2) DEFAULT '0',
  `auto_parentale` int(2) DEFAULT '0',
  `quitance` int(2) DEFAULT '0',
  `ost` int(2) DEFAULT '0',
  `act_mariage` int(2) DEFAULT '0',
  `permi_provisoir` varchar(100) DEFAULT 'Aucune',
  `date_sorti` date DEFAULT NULL,
  `agence` varchar(100) DEFAULT NULL,
  `commentaire` text,
  `photo` varchar(30) DEFAULT NULL,
  `eleve` int(10) NOT NULL,
  PRIMARY KEY (`id_dossier`),
  KEY `eleve` (`eleve`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

-- --------------------------------------------------------

--
-- Structure de la table `eleve`
--

CREATE TABLE IF NOT EXISTS `eleve` (
  `id_eleve` int(10) NOT NULL AUTO_INCREMENT,
  `nom` varchar(30) DEFAULT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `contact` varchar(30) DEFAULT NULL,
  `profession` varchar(100) DEFAULT NULL,
  `adresse` varchar(100) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `sexe` varchar(15) DEFAULT NULL,
  `dor` date NOT NULL,
  `pob` varchar(100) DEFAULT NULL,
  `categorie` varchar(30) DEFAULT NULL,
  `solde` float DEFAULT NULL,
  `forfait` varchar(100) DEFAULT NULL,
  `statut` int(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_eleve`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

-- --------------------------------------------------------

--
-- Structure de la table `examen`
--

CREATE TABLE IF NOT EXISTS `examen` (
  `id_examen` int(10) NOT NULL AUTO_INCREMENT,
  `date_examen` date DEFAULT NULL,
  `examinateur` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_examen`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

-- --------------------------------------------------------

--
-- Structure de la table `examen_eleve`
--

CREATE TABLE IF NOT EXISTS `examen_eleve` (
  `id_examen_eleve` int(10) NOT NULL AUTO_INCREMENT,
  `eleve` int(10) NOT NULL,
  `examen` int(10) NOT NULL,
  `resultat` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_examen_eleve`),
  KEY `eleve` (`eleve`),
  KEY `examen` (`examen`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=48 ;

-- --------------------------------------------------------

--
-- Structure de la table `paiement`
--

CREATE TABLE IF NOT EXISTS `paiement` (
  `id_paiement` int(10) NOT NULL AUTO_INCREMENT,
  `numero` varchar(200) DEFAULT NULL,
  `date_paiement` date NOT NULL,
  `somme` float DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `eleve` int(10) NOT NULL,
  PRIMARY KEY (`id_paiement`),
  KEY `eleve` (`eleve`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=47 ;

-- --------------------------------------------------------

--
-- Structure de la table `program`
--

CREATE TABLE IF NOT EXISTS `program` (
  `id_program` int(10) NOT NULL AUTO_INCREMENT,
  `eleve` int(10) NOT NULL,
  `examen` int(10) NOT NULL,
  PRIMARY KEY (`id_program`),
  KEY `eleve` (`eleve`),
  KEY `examen` (`examen`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=53 ;

-- --------------------------------------------------------

--
-- Structure de la table `programation`
--

CREATE TABLE IF NOT EXISTS `programation` (
  `id_programation` int(10) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) DEFAULT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `dob` varchar(30) DEFAULT NULL,
  `pob` varchar(100) DEFAULT NULL,
  `agence` varchar(100) DEFAULT NULL,
  `examen` int(10) NOT NULL,
  PRIMARY KEY (`id_programation`),
  KEY `examen` (`examen`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id_user` int(10) NOT NULL AUTO_INCREMENT,
  `nom_user` varchar(100) DEFAULT NULL,
  `prenom_user` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `fonction` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`id_user`, `nom_user`, `prenom_user`, `username`, `password`, `fonction`) VALUES
(13, 'admin', 'admin', 'admin', 'zcorp', 'administrateur'),
(14, 'SOMPOUGDOU', 'T. LEON', 'STEGA', '1234', 'administrateur');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `dossier`
--
ALTER TABLE `dossier`
  ADD CONSTRAINT `dossier_ibfk_1` FOREIGN KEY (`eleve`) REFERENCES `eleve` (`id_eleve`);

--
-- Contraintes pour la table `examen_eleve`
--
ALTER TABLE `examen_eleve`
  ADD CONSTRAINT `examen_eleve_ibfk_1` FOREIGN KEY (`eleve`) REFERENCES `eleve` (`id_eleve`),
  ADD CONSTRAINT `examen_eleve_ibfk_2` FOREIGN KEY (`examen`) REFERENCES `examen` (`id_examen`);

--
-- Contraintes pour la table `paiement`
--
ALTER TABLE `paiement`
  ADD CONSTRAINT `paiement_ibfk_1` FOREIGN KEY (`eleve`) REFERENCES `eleve` (`id_eleve`);

--
-- Contraintes pour la table `program`
--
ALTER TABLE `program`
  ADD CONSTRAINT `program_ibfk_1` FOREIGN KEY (`eleve`) REFERENCES `eleve` (`id_eleve`),
  ADD CONSTRAINT `program_ibfk_2` FOREIGN KEY (`examen`) REFERENCES `examen` (`id_examen`);

--
-- Contraintes pour la table `programation`
--
ALTER TABLE `programation`
  ADD CONSTRAINT `fk_PE` FOREIGN KEY (`examen`) REFERENCES `examen` (`id_examen`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
