<?php 

/*
 * Les Variables globales pour configurer le système 
 * Les informations sur votre Auto Ecole 
 */

$config = array(
    'NOM' => 'Leader Auto Ecole',
    'NUMERO' => '+(226) 25-65-33-69',
    'EMAIL' => 'leonsompougdou@gmail.com',
    'LOCATION' => '01 BP 6835 OUAGA 01',
    'ADRESSE' => '',    
);



?>